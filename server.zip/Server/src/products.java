/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author iti
 */
   class Product {
        private int id;
        private String name;
        private int price;
        private String description;
        private String imageUrl;

        public Product(int id, String name, int price, String description, String imageUrl) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.description = description;
            this.imageUrl = imageUrl;
        }

        public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;}
    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
